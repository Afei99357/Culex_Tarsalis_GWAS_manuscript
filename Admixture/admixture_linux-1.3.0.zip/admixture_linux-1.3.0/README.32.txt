
As of version 1.2, admixture is compiled as a 64-bit binary.
admixture32 is a 32-bit version provided for compatibility with older
systems.

--Dave
